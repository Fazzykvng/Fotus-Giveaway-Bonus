async function handler({ email, wallet_address }) {
  try {
    if (!email || !wallet_address) {
      return {
        error: "Missing required fields: email and wallet_address",
      };
    }

    const user = await sql`
      SELECT id, full_name, claimed FROM registrations 
      WHERE email = ${email}
    `;

    if (user.length === 0) {
      return { error: "User not found with this email address" };
    }

    if (user[0].claimed) {
      return { error: "Airdrop has already been claimed for this account" };
    }

    const updatedUser = await sql`
      UPDATE registrations 
      SET wallet_address = ${wallet_address}, claimed = true
      WHERE email = ${email}
      RETURNING id, email, full_name, wallet_address, claimed
    `;

    const confirmationResponse = await fetch(
      "/integrations/chat-gpt/conversationgpt4",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: [
            {
              role: "system",
              content:
                "You are an email composer. Create a professional confirmation email for a successful airdrop claim.",
            },
            {
              role: "user",
              content: `Compose a confirmation email for ${user[0].full_name} at ${email} confirming their airdrop claim has been processed. Their wallet address ${wallet_address} has been recorded. Make it congratulatory and professional.`,
            },
          ],
        }),
      }
    );

    return {
      success: true,
      message: "Airdrop claimed successfully",
      user: {
        id: updatedUser[0].id,
        email: updatedUser[0].email,
        full_name: updatedUser[0].full_name,
        wallet_address: updatedUser[0].wallet_address,
        claimed: updatedUser[0].claimed,
      },
    };
  } catch (error) {
    return { error: "Claim failed: " + error.message };
  }
}
export async function POST(request) {
  return handler(await request.json());
}