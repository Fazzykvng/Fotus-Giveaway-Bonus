async function handler({
  email,
  full_name,
  ssn,
  id_document_url,
  ip_address,
  location_data,
}) {
  try {
    if (!email || !full_name || !ssn || !ip_address) {
      return {
        error: "Missing required fields: email, full_name, ssn, ip_address",
      };
    }

    let locationInfo;
    try {
      locationInfo = JSON.parse(location_data);
    } catch (e) {
      return { error: "Invalid location data format" };
    }

    if (locationInfo.country !== "US") {
      return { error: "Registration is only available for US residents" };
    }

    if (locationInfo.proxy === true || locationInfo.vpn === true) {
      return { error: "VPN/Proxy usage is not allowed for registration" };
    }

    const existingUser = await sql`
      SELECT id FROM registrations 
      WHERE email = ${email} OR ssn = ${ssn}
    `;

    if (existingUser.length > 0) {
      return { error: "User with this email or SSN already registered" };
    }

    const registration = await sql`
      INSERT INTO registrations (email, full_name, ssn, id_document_url, ip_address, location_data)
      VALUES (${email}, ${full_name}, ${ssn}, ${
      id_document_url || null
    }, ${ip_address}, ${location_data})
      RETURNING id, email, full_name, created_at
    `;

    const notificationResponse = await fetch(
      "/integrations/chat-gpt/conversationgpt4",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: [
            {
              role: "system",
              content:
                "You are an email composer. Create a professional notification email about a new user registration.",
            },
            {
              role: "user",
              content: `Compose a notification email for fmenele@gmail.com about a new user registration. User details: Name: ${full_name}, Email: ${email}, Registration ID: ${registration[0].id}, Registration Time: ${registration[0].created_at}`,
            },
          ],
        }),
      }
    );

    const welcomeResponse = await fetch(
      "/integrations/chat-gpt/conversationgpt4",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: [
            {
              role: "system",
              content:
                "You are an email composer. Create a warm welcome email for a new user who just registered.",
            },
            {
              role: "user",
              content: `Compose a welcome email for ${full_name} who just registered with email ${email}. Make it friendly and informative about what happens next.`,
            },
          ],
        }),
      }
    );

    return {
      success: true,
      message: "Registration completed successfully",
      registration_id: registration[0].id,
      user: {
        email: registration[0].email,
        full_name: registration[0].full_name,
        created_at: registration[0].created_at,
      },
    };
  } catch (error) {
    return { error: "Registration failed: " + error.message };
  }
}
export async function POST(request) {
  return handler(await request.json());
}