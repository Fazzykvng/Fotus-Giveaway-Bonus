import { NextResponse } from "next/server";

export const config = {
  matcher: "/integrations/:path*",
};

export function middleware(request) {
  const requestHeaders = new Headers(request.headers);
  requestHeaders.set("x-createxyz-project-id", "f90cd918-54a5-4b46-acb4-a5ffa6ce7435");
  requestHeaders.set("x-createxyz-project-group-id", "6a89e1eb-bc97-4e2d-9c56-7eeecc9d006d");


  request.nextUrl.href = `https://www.create.xyz/${request.nextUrl.pathname}`;

  return NextResponse.rewrite(request.nextUrl, {
    request: {
      headers: requestHeaders,
    },
  });
}